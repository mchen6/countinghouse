var util              = require('util');
var events            = require('events');
var DBLoadTest        = CdifUtil.loadFile(__dirname + '/lib/db-load-test.js');

function DBLoadTestModule() {
  this.on('discover',     this.discoverDevices.bind(this));
  this.on('stopdiscover', this.stopDiscoverDevices.bind(this));
}

util.inherits(DBLoadTestModule, events.EventEmitter);

DBLoadTestModule.prototype.discoverDevices = function() {
  this.emit('deviceonline', new DBLoadTest(), this);
};

DBLoadTestModule.prototype.stopDiscoverDevices = function() {
};

module.exports = DBLoadTestModule;
